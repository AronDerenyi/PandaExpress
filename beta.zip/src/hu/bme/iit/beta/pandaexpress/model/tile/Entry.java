package hu.bme.iit.beta.pandaexpress.model.tile;

import hu.bme.iit.beta.pandaexpress.debug.Logger;

public class Entry extends Tile {
	
	// Constructor
	public Entry() {
		Logger.startFunction(this, "Entry");
		Logger.endFunction();
	}
}
