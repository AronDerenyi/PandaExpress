package hu.bme.iit.beta.pandaexpress.model;

public interface Steppable {
	void step();
}
